
<link rel="stylesheet" href="<?php echo base_url().'assets/global/toastr/toastr.css' ?>">

<!-- CSS Implementing Plugins -->
<link rel="stylesheet" href="<?= base_url('assets/frontend/nifty/vendor/font-awesome/css/all.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/frontend/nifty/vendor/hs-mega-menu/dist/hs-mega-menu.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/frontend/nifty/vendor/fancybox/dist/jquery.fancybox.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/frontend/nifty/vendor/slick-carousel/slick/slick.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/frontend/nifty/vendor/quill/dist/quill.snow.css'); ?>">

<!-- CSS Front Template -->
<link rel="stylesheet" href="<?= base_url('assets/frontend/nifty/css/theme.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/frontend/nifty/css/custom.css'); ?>">

<!-- Select2 -->
<link rel="stylesheet" href="<?= base_url('assets/frontend/nifty/vendor/select2/dist/css/select2.min.css'); ?>">  

<!-- Font -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600&display=swap" rel="stylesheet">
<script type="text/javascript" src="<?= base_url('assets/frontend/nifty/js/jquery-3.5.1.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/frontend/nifty/vendor/jquery/dist/jquery.min.js'); ?>"></script>
