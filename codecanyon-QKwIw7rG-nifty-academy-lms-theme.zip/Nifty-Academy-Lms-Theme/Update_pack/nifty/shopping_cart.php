<!-- Cart Section -->
<div class="container space-1 space-md-2">
	<div class="row" id="shopping_cart_inner_view">
	    <?php include "shopping_cart_inner_view.php"; ?>
	</div>
</div>
<!-- End Cart Section -->	