<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <h1 class="category-name">
                <?php echo $page_title; ?>
            </h1>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12 py-3">
            <?php echo get_frontend_settings('privacy_policy'); ?>
        </div>
    </div>
</div>
